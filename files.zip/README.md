<h1>Inventory Showcase</h1><br>
<p>This is a simple ecommerce responsive website build with django which allow user to add product, product categories and tags but without an checkout page instead of it user can order on whatsapp. Admin can also choose which product to be featured so that it comes front on home page and which categories and tags to be shown.</p>
<h3>Features:</h3>
<ul>
  <li>Checkout via whatsapp [no payment gateway]</li>
  <li>Admin dashboard</li>
  <li>Customizable categories and tags</li>
  <li>Simple and clean UI</li>
</ul>
<p>Note: This project may contain some bugs, kindly report any bud you find</p>
